# ASSALAMUALIKUM
* This Is A Free Working Tools For Cracking Old And New Facebook Account Like (2004 To Now)

# Features⬇️:

* [1] New Id Cloning
* [2] 2004-08 Cloning
* [3] 2009-10 Cloning
* [4] 2011-14 Cloning

# Installation ⬇️:
```
pkg update
pkg upgrade
pkg install python
pkg install git
pip install requests
pip install bs4
pip install rich
rm -rf HackOld
git clone https://github.com/STLP-TEAM/HackOld
cd HackOld
python stlp.py
```

# Tested On⬇️:
* Termux
* Kali Linux
* Ubuntu
* Debain

# Join Our Facebook Group ⬇️:
https://facebook.com/groups/spamming.termux.learning.point/
